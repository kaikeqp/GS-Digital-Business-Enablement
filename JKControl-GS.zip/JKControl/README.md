# gestao-portaria-dbe
Prova realizado pelos seguintes alunos<br>
Nome: Giulio Cesar Costa Bernardi <br>
RM: 86993 <br>

Nome: André dos Santos Menezes de Souza <br>
RM: 88112
